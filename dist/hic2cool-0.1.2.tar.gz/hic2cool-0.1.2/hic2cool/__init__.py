from hic2cool.hic2cool import hic2cool_convert
from hic2cool._version import __version__

__all__ = ["hic2cool_convert", "__version__"]
